// script.js

// Adicione uma função para mostrar uma mensagem de boas-vindas após o login bem-sucedido
function showWelcomeMessage() {
    const welcomeContainer = document.getElementById('welcome-container');
    welcomeContainer.style.display = 'block';
}

// Adicione uma função para ocultar a mensagem de boas-vindas
function hideWelcomeMessage() {
    const welcomeContainer = document.getElementById('welcome-container');
    welcomeContainer.style.display = 'none';
}

// Adicione um evento para mostrar a mensagem de boas-vindas após o login
document.addEventListener('DOMContentLoaded', function () {
    // Verifique se a mensagem de boas-vindas deve ser exibida (se o usuário está autenticado)
    if (authenticated) {
        showWelcomeMessage();
    }
});

// Adicione um evento para ocultar a mensagem de boas-vindas ao fazer logout
const logoutButton = document.getElementById('logout-button');
logoutButton.addEventListener('click', function () {
    // Realize o logout, por exemplo, redirecionando o usuário de volta para a página de login
    hideWelcomeMessage();
});
