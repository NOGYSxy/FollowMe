<?php
session_start();

// Credenciais do banco de dados
$servername = "localhost";
$username_db = "Aluno3DS";
$password_db = "SenhaBD3";
$dbname = "BANCO3DS";

// Conectar ao banco de dados
$conn = new mysqli($servername, $username_db, $password_db, $dbname);

// Verificar a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Processar o formulário de cadastro
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_username = $_POST['new_username'];
    $new_password = $_POST['new_password'];

    // Verificar se o nome de usuário já existe
    $check_username_sql = "SELECT * FROM FOLLOWME WHERE usuario = '$new_username'";
    $check_result = $conn->query($check_username_sql);

    if ($check_result->num_rows > 0) {
        echo "Nome de usuário já existe. Escolha outro.";
    } else {
        // Gerar um salt aleatório
        $salt = bin2hex(random_bytes(16));

        // Concatenar o salt à senha
        $combined_password = $new_password . $salt;

        // Gerar um hash usando o password_hash com o salt
        $hashed_password = password_hash($combined_password, PASSWORD_DEFAULT);

        // Inserir dados na tabela
        $insert_sql = "INSERT INTO FOLLOWME (usuario, senha) VALUES ('$new_username', '$hashed_password')";

        if ($conn->query($insert_sql) === TRUE) {
            // Cadastro bem-sucedido, redirecionar para a página de login
            $_SESSION['authenticated'] = true;
            header("Location: login.php");
            exit();
        } else {
            echo "Erro ao cadastrar: " . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cadastro</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <div id="login-container">
        <h1>Cadastro</h1>
        <form action="cadastro.php" method="post">
            <label for="new_username">Novo Usuário:</label>
            <input type="text" id="new_username" name="new_username" required>
            <br>
            <label for="new_password">Nova Senha:</label>
            <input type="password" id="new_password" name="new_password" required>
            <br>
            <button type="submit">Cadastrar</button>
        </form>
        
        <p>Já possui uma conta? <a href="login.php">Faça login aqui</a>.</p>
        <p>ou</p>
        <form action="login.php" method="get">
            <button type="submit">Ir para a tela de Login</button>
        </form>
    </div>
</body>
</html>

