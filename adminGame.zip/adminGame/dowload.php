<?php
session_start();

if (!isset($_SESSION['authenticated']) || !$_SESSION['authenticated']) {
    header("Location: index.html");
    exit();
}

$upload_dir = 'uploads/';
$files = scandir($upload_dir);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Site de Upload</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <div id="download-container">
        <h1>Download de Arquivos</h1>
        <ul>
            <?php foreach ($files as $file) {
                if ($file != "." && $file != "..") {
                    echo "<li><a href='uploads/$file' download>$file</a></li>";
                }
            } ?>
        </ul>
    </div>
</body>
</html>
