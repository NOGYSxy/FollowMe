<?php
session_start();

if (!isset($_SESSION['authenticated']) || !$_SESSION['authenticated']) {
    header("Location: index.html");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $upload_dir = 'uploads/';
    $uploaded_file = $upload_dir . basename($_FILES['file']['name']);

    if (move_uploaded_file($_FILES['file']['tmp_name'], $uploaded_file)) {
        echo "Upload bem-sucedido. <a href='download.php'>Ir para a página de download</a>";
    } else {
        echo "Erro no upload do arquivo.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Site de Upload</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css">
</head>
<body>
    <div id="upload-container">
        <h1>Upload de Arquivo</h1>
        <form action="upload.php" method="post" enctype="multipart/form-data">
            <input type="file" name="file" required>
            <br>
            <button type="submit">Enviar</button>
        </form>
    </div>
</body>
</html>
